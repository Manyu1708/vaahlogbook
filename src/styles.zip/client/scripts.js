
const { event } = require("jquery");

  
    
    function display() {
    var x = document.getElementById("includehtmltest");
    var y = document.getElementById("data-form");
    
    if (x.style.display === "none") {
        x.style.display = "block";
        y.style.display = "none";
      
      } else {
        x.style.display = "none";
        y.style.display = "none";
      
      }
    
    //    document.getElementById('box').setAttribute("style", "display:block;");
    }
    
    
   async function iframex(iframeId)
   {
    var iFrameBox = 'includehtmltest';
    document.getElementById(iFrameBox).style.display = "none";
    var delayInMilliseconds = 100; //1 second


    var iframediv = document.getElementById(iFrameBox);
    var innerDoc = iframediv.contentWindow.document;//.querySelector("form-group");
switch (iframeId) {
    case 'add-lb':
    document.getElementById(iFrameBox).src='/logbook';
    display();
    break;
case 'view-lb':
  document.getElementById(iFrameBox).src='/viewlogbook';
//   await fetch('/viewlogbook').then(function(response) {
//     // When the page is loaded convert it to text
//     return response.text();
// }).then((html) => {
// console.log(html);
// document.getElementById('MyDiv').innerHTML = html;
// }

// );
    display();
    // viewLogBookOnLoad();
    break;
  case 'chgpwd':
    console.log('123');
    document.getElementById(iFrameBox).src='/changepassword';
    display();
    break;
  case 'add-aelp':
    document.getElementById(iFrameBox).src='/AELP';
    display();
  break;
  case 'add-rating':
    document.getElementById(iFrameBox).src='/Endorsement';
    display();
  break;
  case 'view-rating':
    document.getElementById(iFrameBox).src='/ViewEndorsement';
    display();
  break;
  case 'view-stress':
    document.getElementById(iFrameBox).src='/ViewStress';
    display();
  break;
  
    case 'add-prof':
    document.getElementById(iFrameBox).src='/Proficiency';
    display();
  break;
  case 'add-art':
    document.getElementById(iFrameBox).src='/Training';
    display();
  break;
  case 'view-art':
    document.getElementById(iFrameBox).src='/ViewTraining';
    display();
  break;
    case 'view-ojtlb':
  document.getElementById(iFrameBox).src='/viewlogbook';
    display();
   
setTimeout(function() {
  //your code to be executed after 1 second
 var iframediv = document.getElementById(iFrameBox);
var innerDoc = iframediv.contentWindow.document;//.document.querySelector("DIV");
innerDoc.getElementsByClassName("trainee")[0].style.display = "block";
}, delayInMilliseconds);
    break;
    
    case 'view-trlb':
      document.getElementById(iFrameBox).src='/viewlogbook';
      display();    
setTimeout(function() {
  //your code to be executed after 1 second
 var iframediv = document.getElementById(iFrameBox);
var innerDoc = iframediv.contentWindow.document;//.document.querySelector("DIV");

innerDoc.getElementsByClassName("instructor")[0].style.display = "block";
}, delayInMilliseconds);
  //innerDoc.getElementsByClassName("instructor")[0].style.visibility='hidden'
      break;
case 'add-ojtlb':
  document.getElementById(iFrameBox).src='/logbook';
  display();
  setTimeout(function() {
    //your code to be executed after 1 second
   var iframediv = document.getElementById(iFrameBox);
  var innerDoc = iframediv.contentWindow.document;//.document.querySelector("DIV");
  innerDoc.getElementsByClassName("trainee")[0].style.display = "block";
  innerDoc.getElementsByClassName("purpose")[0].style.display = "block";
  }, delayInMilliseconds);
break;
case 'add-trlb':
  document.getElementById(iFrameBox).src='/logbook';
  display();
  setTimeout(function() {
    //your code to be executed after 1 second
   var iframediv = document.getElementById(iFrameBox);
  var innerDoc = iframediv.contentWindow.document;//.document.querySelector("DIV");
  innerDoc.getElementsByClassName("instructor")[0].style.display = "block";
  innerDoc.getElementsByClassName("purpose")[0].style.display = "block";
  }, delayInMilliseconds);
break;
      case 'add-med':
        document.getElementById(iFrameBox).src='/Medical';
    display();
  break;
  case 'view-med':
        document.getElementById(iFrameBox).src='/ViewMedical';
    display();
  break;
  case 'view-prof':
    document.getElementById(iFrameBox).src='/ViewProficiency';
display();
break;
  case 'add-otd':
    document.getElementById(iFrameBox).src='/OTD';
    display();
  break;
  case 'view-otd':
    document.getElementById(iFrameBox).src='/ViewOTD';
    display();
  break;
  case 'view-aelp':
    document.getElementById(iFrameBox).src='/ViewAELP';
    display();
  break;


    default:
    break;
}

   }


  

    
function myFunction() {
  // Get the checkbox
  var checkBox = document.getElementById("datecheck");
  // Get the output text
  var datefrom = document.getElementById("Date_From").value;
var dateto = document.getElementById("Date_To");
  // If the checkbox is checked, display the output text
  if (checkBox.checked == true){
      console.log(datefrom);
    document.getElementById("Date_To").value = datefrom;
  } 
}

